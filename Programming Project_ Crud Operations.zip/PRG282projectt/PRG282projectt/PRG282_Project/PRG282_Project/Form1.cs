﻿using PRG282_Project.DataLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG282_Project
{
    public partial class Form1 : Form
    {
        FileHandler fileHandler = new FileHandler();
        MainForm main = new MainForm();
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtuserdetails_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            
            
            if (fileHandler.Read(txtuserdetails.Text, txtpassword.Text) ==true)
            {
                
                MessageBox.Show("Login Successful");
                main.Show();
                this.Hide();
            }
            else
            {
                
                MessageBox.Show("Username and/or Password not found!. Sign Up?");
               
                
            }
           

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            CreateAccount signUp = new CreateAccount();
            signUp.Show();
            this.Hide();
        }
    }
}
