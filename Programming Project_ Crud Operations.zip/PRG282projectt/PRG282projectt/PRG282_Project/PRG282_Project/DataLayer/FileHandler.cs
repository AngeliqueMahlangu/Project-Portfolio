﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace PRG282_Project.DataLayer
{
    internal class FileHandler
    {
        public string path = @"student.txt";

        public List<login> GetLogins()
        {
            List<login> loginDetails = new List<login>();
            
            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);

                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    login login = new login
                    {
                        Username = parts[0],
                        Password = parts[1]
                    };
                }
            }
            else
            {
                return loginDetails;
            }

            return loginDetails;
        }

        public void WriteLoginDetails(string username, string password)
        {
            try
            {
                using (StreamWriter st = new StreamWriter(path, true))
                {
                    st.WriteLine($"{username},{password}");
                }
            }
            catch (Exception e)
            {
                MessageBox.Show($"Error");
            }
        }
        public bool Read(string username, string password)
        {
            
            bool flag = false;
            
            try
            {
               
                using (StreamReader sr = new StreamReader(path))
                {
                    List<string> mylist = new List<string>(); 
                    mylist = File.ReadAllLines(path).ToList();
                    foreach (string line in mylist)
                    {
                        string[] field = line.Split(',');

                        if (field[0] == username && field[1] == password)
                        {
                            return flag = true;

                        }
                    }
                   

                }

            }
           
            catch (Exception e)
            {
            
                MessageBox.Show(e.Message);
            }
            
            return flag;

        }

    }
}
