﻿using PRG282_Project.DataLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PRG282_Project
{
    public partial class RegisterForm : Form
    {
        Datahandler handler = new Datahandler();
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            handler.AddStudent2(int.Parse(stdNumber.Text), txtName.Text, txtSurname.Text, txtDOB.Text,gender.Text, txtPhone.Text,txtAddress1.Text ,txtMdlCode.Text);
            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
            this.Hide();

        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {
            handler.getModules(txtMdlCode);
        }
    }
}
