﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//namespace
using PRG282_Project.DataLayer;

namespace PRG282_Project.BusinessLogicLayer
{
    internal class Modules
    {
        //Fields and Properties
        public string ModuleId { get; set; }
        public string ModuleName { get; set; }
        public string ModuleDescription { get; set; }
        public string SourceLink { get; set; }

        //Default Constructor
        public Modules() { }

        //Constructor with parameters
        public Modules(string moduleId, string moduleName, string moduleDescription, string sourceLink)
        {
            ModuleId = moduleId;
            ModuleName = moduleName;
            ModuleDescription = moduleDescription;
            SourceLink = sourceLink;
        }

        //create instance of data handler
        Datahandler handler = new Datahandler();

        public void CreateModule(List<Modules> moduleDetails) 
        { 
            //create query string - create new module
            string query = $"INSERT INTO Modules VALUES {moduleDetails[0]},{moduleDetails[1]}," +
                $"{moduleDetails[2]},{moduleDetails[3]}";

            try
            {
                //execute query
                handler.CRUD_Procedures2(query);
            }
            catch (Exception)
            {
                //if not able to create new module
                MessageBox.Show("Error - unable to create new module.");
            }
        }

        public void DisplayModules() 
        {
            //create query string - view all modules
            string query = "SELECT * FROM Modules";

            try
            {
                //execute query
                handler.CRUD_Procedures2(query);
            }
            catch (Exception)
            {
                //if not able to display modules
                MessageBox.Show("Error - unable to display modules.");
            }
        }

        public void UpdateModule(string moduleId, List<Modules> updatedDetails) 
        {
            //create query string - update all information of specified module
            string query = $"UPDATE Modules SET Module_Code = {updatedDetails[0]}, Module_Name = {updatedDetails[1]}," +
                $"Module_Description = {updatedDetails[2]}, Source_Link = {updatedDetails[3]} WHERE Module_Code = {moduleId}";

            try
            {
                //execute query
                handler.CRUD_Procedures2(query);
            }
            catch (Exception)
            {
                //if not able to update module
                MessageBox.Show("Error - unable to update module.");
            }
        }

        public void DeleteModule(string moduleId) 
        {
            //create query string - delete record of specified module
            string query = $"DELETE FROM Modules WHERE Module_Code = {moduleId}";

            try
            {
                //execute query
                handler.CRUD_Procedures2(query);
            }
            catch (Exception)
            {
                //if not able to delete module
                MessageBox.Show("Error - unable to delete module.");
            }
        }

        public void FindModule(string moduleId) 
        {
            //create query string - select all fields for specified module
            string query = $"SELECT * FROM Modules WHERE Module_Code = {moduleId}";

            try
            {
                //execute query
                handler.CRUD_Procedures2(query);
            }
            catch (Exception)
            {
                //if not able to find module
                MessageBox.Show("Error - module does not exist.");
            }
        }
    }
}
