﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG282_Project.PresentationLayer
{
    internal class StudentInfo
    {
        string stdName, stdSurname, mdlName, address;
        bool gender;
        int DOB, phone, stdNumber, mdlCode;

        public StudentInfo(string stdName, string stdSurname, string mdlName, string address, bool gender, int dOB, int phone, int stdNumber, int mdlCode)
        {
            this.StdName = stdName;
            this.StdSurname = stdSurname;
            this.MdlName = mdlName;
            this.Address = address;
            this.Gender = gender;
            DOB1 = dOB;
            this.Phone = phone;
            this.StdNumber = stdNumber;
            this.MdlCode = mdlCode;
        }

        public string StdName { get => stdName; set => stdName = value; }
        public string StdSurname { get => stdSurname; set => stdSurname = value; }
        public string MdlName { get => mdlName; set => mdlName = value; }
        public string Address { get => address; set => address = value; }
        public bool Gender { get => gender; set => gender = value; }
        public int DOB1 { get => DOB; set => DOB = value; }
        public int Phone { get => phone; set => phone = value; }
        public int StdNumber { get => stdNumber; set => stdNumber = value; }
        public int MdlCode { get => mdlCode; set => mdlCode = value; }
    }
}
