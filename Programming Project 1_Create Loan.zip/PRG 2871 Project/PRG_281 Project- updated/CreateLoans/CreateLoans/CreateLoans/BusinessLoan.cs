﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateLoans
{
    internal class BusinessLoan : Loans
    {
        public BusinessLoan(string name, string surname, char loanType, double loanAmount, double interest, int term) : base(name, surname, loanType, loanAmount, interest, term)
        {
        }
        public BusinessLoan() 
        {
            
        }
        public override double CalInterestRate(double InterestRate)
        {
            InterestRate = InterestRate + 0.01; 
            return InterestRate;
        }

        public static List<Loans> BusinessLoanList = new List<Loans>();

        public override void TotalOwed()
        {
            bool cont = true;
            do
            {
                Console.WriteLine("Enter the name of the person you would like the amount owed ");
                Name = Console.ReadLine();



            } while (cont);
        }
    }
}
