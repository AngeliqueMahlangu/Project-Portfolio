﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateLoans
{
    public interface iLoanConstants
    {
        int ShortTermLoan { get; }
        int MediumTermLoan { get; }
        int LongTermLoan { get; }

        string CompanyName { get; }
        int MaxLoanAmount { get; }
    }

    public class Loan_Constants
    {

        public int ShortTermLoan { get { return 1; } }
        public int MediumTermLoan { get { return 3; } }
        public int LongTermLoan { get { return 5; } }


        public string CompanyName { get { return "Unique Building Services Loan Company"; } }
        public int MaxLoanAmount { get { return 100000; } }

    }

}
