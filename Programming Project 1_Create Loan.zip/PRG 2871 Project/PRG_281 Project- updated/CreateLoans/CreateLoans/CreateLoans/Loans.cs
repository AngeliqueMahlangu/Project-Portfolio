﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateLoans
{
    internal abstract class Loans
    {
        public string Name, surname;
        public char LoanType;
        public double LoanAmount, interest;
        public int Term;

        protected Loans(string name, string surname, char loanType, double loanAmount, double interest, int term)
        {
            Name = name;
            this.surname = surname;
            LoanType = loanType;
            LoanAmount = loanAmount;
            Interest = interest;
            Term = term;
        }
        public Loans()
        {

        }
        public abstract double CalInterestRate(double InterestRate);

        public static List<Loans> LoanList = new List<Loans>();

        public abstract void TotalOwed();
        public override string ToString()
        {
            return "Name: " + Name + "\tSurname: " + surname + "\tLoan Type: " + LoanType + "\tLoan Amount: " + LoanAmount + "\tInterest: " + interest + "\tTerm: " + Term;
        }

        public string Name1 { get => Name; set => Name = value; }
        public string Surname { get => surname; set => surname = value; }
        public char LoanType1 { get => LoanType; set => LoanType = value; }
        public double LoanAmount1 { get => LoanAmount; set => LoanAmount = value; }
        public double Interest { get => interest; set => interest = value; }
        public int Term1 { get => Term; set => Term = value; }
    }
}
