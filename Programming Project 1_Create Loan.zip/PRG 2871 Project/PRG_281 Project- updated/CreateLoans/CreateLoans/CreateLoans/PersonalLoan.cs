﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CreateLoans
{
    internal class PersonalLoan : Loans
    {
       
        public PersonalLoan(string name, string surname, char loanType, double loanAmount, double interest, int term) : base(name, surname, loanType, loanAmount, interest, term)
        {
     
        }
        public PersonalLoan()
        {

        }
        public static List<Loans> PersonalLoanList = new List<Loans>();

        public override double CalInterestRate(double InterestRate)
        {
            InterestRate = InterestRate + 0.02;
            return InterestRate;
        }


        public override void TotalOwed()
        {
            bool cont = true;
            do
            {
                Console.WriteLine("Enter the nam" +
                    "e of the person you would like the amount owed ");
                Name = Console.ReadLine();



            } while (cont);
        }
    }
}
