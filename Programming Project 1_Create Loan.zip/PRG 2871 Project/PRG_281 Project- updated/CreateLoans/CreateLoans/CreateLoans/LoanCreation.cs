﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CreateLoans
{
    internal class LoanCreation
    {
        public List<Loans> CreateLoan()
        {
            string name, surname;
            char LoanType;
            double LoanAmount, interest, primeInterest;
            int Term;
            List<Loans> LoansList = new List<Loans>();
            BusinessLoan  businessLoan= new BusinessLoan();
            PersonalLoan personalLoan = new PersonalLoan();
            Console.WriteLine("Please enter the prime interest rate");
            primeInterest = (double.Parse(Console.ReadLine())) / 100;
            Loans[] loan = new Loans[5];
            Loan_Constants loanConstants = new Loan_Constants();
            for (int i = 0; i < 5; i++) 
            {
                Console.WriteLine("\nLoan " + (i+1));
                Console.WriteLine("Customer first name:");
                name = Console.ReadLine();
                Console.WriteLine("Last name:");
                surname = Console.ReadLine();
                Console.WriteLine("loan type:\np for personal loans or b for bussines loans");
                LoanType = char.Parse(Console.ReadLine());
                while (LoanType!='b'&& LoanType!='p')
                {
                    Console.WriteLine("Enter p for a personal loan and b for a bussines loan");
                    LoanType = char.Parse(Console.ReadLine());
                }

                Console.WriteLine("Loan amount:");
                LoanAmount = double.Parse(Console.ReadLine());

                while (LoanAmount>loanConstants.MaxLoanAmount)
                {
                    Console.WriteLine("The maximum loan amount is R 100 000.\nPlease re-enter the loan amount");
                    LoanAmount = double.Parse(Console.ReadLine());
                }
                Console.WriteLine("Term:");
                Term = int.Parse(Console.ReadLine());
                if (Term!=1 && Term!=3 && Term!=5)
                {
                    Term=1;
                    Console.WriteLine("You did not select a valid term(1,3 or 5) so the default term of 1 has been assigned");
                }
            
                if (LoanType == 'p')
                {
                    interest = personalLoan.CalInterestRate(primeInterest);
                    LoansList.Add(new PersonalLoan(name, surname, LoanType, LoanAmount, interest, Term));
                }
                else
                {
                    interest = businessLoan.CalInterestRate(primeInterest);
                    LoansList.Add(new BusinessLoan(name, surname, LoanType, LoanAmount, interest, Term));
                }

            }
            Console.WriteLine("\nList of Loans:");
            foreach ( var item in LoansList)
            {
                Console.WriteLine(item);
            }
            return LoansList;
        }
    }
}
