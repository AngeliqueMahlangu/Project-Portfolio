﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CreateLoans
{
    internal class Program
    {
        enum Menu
        {
        inputLoanInformation=1,
        calculateLoan,
        totalInterest,
        Exit
        }
        static void Main(string[] args)
        {
            List<Loans> LoansList = new List<Loans>();
            PersonalLoan personalLoan = new PersonalLoan();
            personalLoan.LoanType = 'p';
            LoansList.Add(personalLoan);

            BusinessLoan businessLoan = new BusinessLoan();
            businessLoan.LoanType = 'b';
            LoansList.Add(businessLoan);

            bool cont=true;
            bool check = true;


            while (cont)
            {
                Console.WriteLine("What would you like to do with The loans ? \n1.Create Loan\n2.Calculate amount owed \n3.Calculate the total Interest\n4.Exit");
                int choice = int.Parse(Console.ReadLine());
                if (check &&choice !=1) 
                {
                    Console.WriteLine("You have to start by Creating a loan");
                    choice = 1;
                }
                
                switch ((Menu)choice)
                {
                    case Menu.inputLoanInformation:
                        Console.WriteLine("To properly start the program create 5 loans");
                        LoanCreation createLoan = new LoanCreation();
                        LoansList=createLoan.CreateLoan();
                        check=false;
                        break;
                    case Menu.calculateLoan:
                        Console.WriteLine("Who's Loan do you want to calculate?(name)");
                        string CalculateLoanChoice=Console.ReadLine();
                        foreach (var item in LoansList)
                        {
                            if (CalculateLoanChoice == item.Name)
                            {
                                double Total = item.LoanAmount + item.interest * item.LoanAmount;
                                Console.WriteLine("The total amount that will be owed after "+ item.Term + " years will be " + Total +"\n");
                            }
                        }

                        break;
                    case Menu.totalInterest:
                        Console.WriteLine("Whos interest do you want to calculate?(name)");
                        string CalculateInterestChoice = Console.ReadLine();
                        foreach (var item in LoansList)
                        {
                            if (CalculateInterestChoice == item.Name)
                            {
                                double Total = item.interest * item.LoanAmount;
                                Console.WriteLine("The total Interest that will be owed after " + item.Term + " years will be R " + Total + "\n");
                            }
                        }
                        break;
                    case Menu.Exit:
                        cont = false;
                        break;
                    default:
                        break;
                }
            }

        }
    }
}
