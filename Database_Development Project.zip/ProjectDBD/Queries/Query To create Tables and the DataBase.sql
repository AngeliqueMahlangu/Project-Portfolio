--Creating Database
Create Database [Belgium Campus UniversityDB]
-- Use the database
USE [Belgium Campus UniversityDB];

--Create the Student table
CREATE TABLE Student (
    student_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(50),
    phone_number VARCHAR(50),
    date_of_birth DATE,
    gender VARCHAR(10),
    address VARCHAR(100),
    nationality VARCHAR(50),
    status VARCHAR(50),
    start_date DATE,
    end_date DATE
);
-- Create the StudentInsert table to store the new data inserted into the Students table
CREATE TABLE StudentInsert (
    student_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(50),
    phone_number VARCHAR(50),
    date_of_birth DATE,
    gender VARCHAR(10),
    address VARCHAR(100),
    nationality VARCHAR(50),
    status VARCHAR(50),
    start_date DATE,
    end_date DATE
);


--Create the table Assessment
CREATE TABLE Assessment (
    AssessmentID INT PRIMARY KEY,
    Student_id INT,
    course_id INT,
    AssessmentDate DATE,
    Score FLOAT,
    CONSTRAINT FK_Assessment_Student FOREIGN KEY (Student_id)
    REFERENCES Student (Student_id),
    CONSTRAINT FK_Assessment_Course FOREIGN KEY (course_id)
    REFERENCES Course (course_id)
);

-- Create the Course table
CREATE TABLE Course (
    course_id INT PRIMARY KEY,
    course_name VARCHAR(50),
    description VARCHAR(100),
    credit_hours INT
);

-- Create the Course Offering table
CREATE TABLE Course_Offering (
    offering_id INT PRIMARY KEY,
    start_date DATE,
    end_date DATE,
    course_id INT FOREIGN KEY REFERENCES Course(course_id)
);

-- Create the Enrollment table
CREATE TABLE Enrollment (
    enrollment_id INT PRIMARY KEY,
    grade VARCHAR(10),
    status VARCHAR(50),
    mid_term_score INT,
    attendance_score INT,
    weekly_assessment_score INT,
    student_id INT FOREIGN KEY REFERENCES Student(student_id),
    offering_id INT FOREIGN KEY REFERENCES Course_Offering(offering_id)
);

-- Create the Final Exam table
CREATE TABLE Final_Exam (
    exam_id INT PRIMARY KEY,
    date DATE,
    score INT,
    enrollment_id INT FOREIGN KEY REFERENCES Enrollment(enrollment_id)
);

-- Create the Staff table
CREATE TABLE Staff (
    staff_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(50),
    phone_number VARCHAR(50),
    date_of_birth DATE,
    gender VARCHAR(10),
    position VARCHAR(50),
    salary FLOAT
);

Select*
from Staff
-- Create the Teaching table
CREATE TABLE Teaching (
    teaching_id INT PRIMARY KEY,
    subject VARCHAR(50),
    start_date DATE,
    end_date DATE,
    staff_id INT FOREIGN KEY REFERENCES Staff(staff_id)
);

-- Create the Administration table
CREATE TABLE Administration (
    admin_id INT PRIMARY KEY,
    department VARCHAR(50),
    start_date DATE,
    end_date DATE,
    staff_id INT FOREIGN KEY REFERENCES Staff(staff_id)
);

-- Create the Financial table
CREATE TABLE Financial (
    financial_id INT PRIMARY KEY,
    transaction_type VARCHAR(50),
    amount FLOAT,
    date DATE,
    student_id INT FOREIGN KEY REFERENCES Student(student_id),
    staff_id INT FOREIGN KEY REFERENCES Staff(staff_id)
);

--POPULATING TABLES

--Inserting data in the Course Table
GO

INSERT INTO Course (course_id, course_name, description, credit_hours)
VALUES
    (1, 'ACW171', 'ACW-Academic Writing', 3),
    (2, 'COA171', 'Computer Architecture', 4),
    (03, 'COA161', 'Computer Architecture', 4),
    (04, 'DBD161', 'DBD-Database Development', 3),
    (5, 'DBD171', 'DBD-Database Development', 3),
    (6, 'DBD181', 'DBD-Database Development', 3),
    (7, 'DBD271', 'DBD-Database Development', 3),
    (8, 'DBD281', 'DBD-Database Development', 3),
    (9, 'DBD371', 'DBD-Database Development', 3),
    (10, 'MAT171', 'MAT- Mathematics', 3),
    (11, 'MAT181', 'MAT- Mathematics', 3),
    (12, 'MAT161', 'MAT- Mathematics', 3),
    (13, 'MAT271', 'MAT- Mathematics', 3),
    (14, 'MAT281', 'MAT- Mathematics', 3),
    (15, 'MAT381', 'MAT- Mathematics', 3),
    (16, 'MAT371', 'MAT- Mathematics', 3),
    (17, 'NWD171', 'NWD-Network Development', 4),
    (18, 'NWD181', 'NWD-Network Development', 4),
    (19, 'NWD161', 'NWD-Network Development', 4),
    (20, 'NWD271', 'NWD-Network Development', 4),
    (21, 'NWD281', 'NWD-Network Development', 4),
    (22, 'PRG161', 'PRG-Programing', 3),
    (23, 'PRG171', 'PRG-Programing', 3),
    (24, 'PRG181', 'PRG-Programing', 3),
    (25, 'PRG261', 'PRG-Programing', 3),
    (26, 'PRG271', 'PRG-Programing', 3),
    (27, 'PRG281', 'PRG-Programing', 3),
    (28, 'PRG371', 'PRG-Programing', 3),
    (29, 'PRG381', 'PRG-Programing', 3),
    (30, 'STA171', 'STA- Statistics', 3),
    (31, 'STA181', 'STA- Statistics', 3),
    (32, 'STA161', 'STA- Statistics', 3),
    (33, 'STA271', 'STA- Statistics', 3),
    (34, 'STA281', 'STA- Statistics', 3),
    (35, 'STA381', 'STA- Statistics', 3),
    (36, 'WPR161', 'WPR-Web Programing', 4),
    (37, 'WPR261', 'WPR-Web Programing', 4),
    (38, 'WPR181', 'WPR-Web Programing', 4)

--Populating Data into the Course offering

INSERT INTO Course_Offering (offering_id, start_date, end_date, course_id) VALUES
    (1, '2023-04-03', '2023-06-23', 1),
    (2, '2023-05-01', '2023-07-21', 2),
    (3, '2023-06-05', '2023-08-25', 3),
    (4, '2023-07-03', '2023-09-22', 1),
    (5, '2023-08-07', '2023-10-27', 2);


Go
-- Get the list of course offerings
DECLARE @CourseOfferings TABLE (
    offering_id INT
);

INSERT INTO @CourseOfferings (offering_id)
SELECT offering_id FROM Course_Offering;

-- Get the list of students
DECLARE @Students TABLE (
    student_id INT
);

INSERT INTO @Students (student_id)
SELECT student_id FROM Student;

-- Populate the Enrollment table
DECLARE @Enrollments TABLE (
    enrollment_id INT,
    grade VARCHAR(10),
    status VARCHAR(50),
    mid_term_score INT,
    attendance_score INT,
    weekly_assessment_score INT,
    student_id INT,
    offering_id INT
);

DECLARE @i INT = 1;

WHILE (@i <= 50) BEGIN
    INSERT INTO @Enrollments (enrollment_id, grade, status, mid_term_score, attendance_score, weekly_assessment_score, student_id, offering_id)
    VALUES (@i, 
            CASE WHEN RAND() < 0.6 THEN 'Pass' ELSE 'Fail' END, -- Random pass/fail grade
            'Enrolled', -- All students are assumed to be enrolled
            CONVERT(INT, (RAND() * 50) + 50), -- Random mid-term score between 50 and 100
            CONVERT(INT, (RAND() * 20)), -- Random attendance score between 0 and 20
            CONVERT(INT, (RAND() * 30)), -- Random weekly assessment score between 0 and 30
            (SELECT TOP 1 student_id FROM @Students ORDER BY NEWID()), -- Random student ID
            (SELECT TOP 1 offering_id FROM @CourseOfferings ORDER BY NEWID()) -- Random course offering ID
            );
    SET @i += 1;
END;

-- Insert the data from the temporary table into the Enrollment table
INSERT INTO Enrollment (enrollment_id, grade, status, mid_term_score, attendance_score, weekly_assessment_score, student_id, offering_id)
SELECT enrollment_id, grade, status, mid_term_score, attendance_score, weekly_assessment_score, student_id, offering_id
FROM @Enrollments;


--Populating Staff Table

Go
INSERT INTO Staff
(staff_id,Last_Name,First_Name,Email,phone_number,date_of_birth,Gender,position,salary)
VALUES('1','Gift','Mudare','gift@belgiumcampus.ac.za','0826952437','08/08/75','Male','Lecturer','30000'),
		('2','Raymond','Hood','hood1@belgiumcampus.ac.za','0843064064','05/31/89','Male','Lecturer','30000'),
		('3','Matilda','Chiruka','matilda01@belgiumcampus.ac.za','0828272885','03/25/85','Female','Lecturer','30000'),
		('4','Lerato','Setswe','Setswe01@belgiumcampus.ac.za','0822224993','09/19/92','Female','Lecturer','15000'),
		('5','Desire','Sundare','desire@belgiumcampus.ac.za','0832335987','06/07/79','Male','Lecturer','30000')


Go
-- Populating Final_Exam table
INSERT INTO Final_Exam (exam_id, date, score, enrollment_id)
VALUES
  (1, '2022-01-16', 75, 1),
  (2, '2022-01-16', 85, 2),
  (3, '2022-01-16', 80, 3),
  (4, '2022-01-16', 92, 4),
  (5, '2022-01-16', 87, 5);


-- Stored procedures, views, triggers, and other objects with a description for each


/*Stored Procedure for Updating Course Offerings: 
This stored procedure will take input parameters for the course ID, start date, and end date,
and update the corresponding records in the Course_Offering table. 
It will also include error handling for cases where the input dates overlap with existing offerings.*/
Go
CREATE PROCEDURE UpdateCourseOfferings 
    @course_id INT, 
    @start_date DATE, 
    @end_date DATE
AS
BEGIN
    IF EXISTS (SELECT * FROM Course_Offering WHERE course_id = @course_id 
               AND @start_date < end_date AND start_date < @end_date)
        BEGIN
            RAISERROR('Course Offering dates overlap with existing record', 16, 1)
            RETURN
        END
    ELSE
        BEGIN
            UPDATE Course_Offering SET start_date = @start_date, end_date = @end_date 
            WHERE course_id = @course_id
        END
END

/*View for Student Enrollment: 
This view will join the Enrollment table with the Student and Course tables 
to provide a comprehensive overview of which students are enrolled in which courses, 
along with their grades and attendance scores.*/
go
CREATE VIEW StudentEnrollment AS
		SELECT s.student_id, s.first_name, s.last_name, c.course_name, e.grade, e.status, 
		e.mid_term_score, e.attendance_score, e.weekly_assessment_score
		FROM Enrollment e
		JOIN Student s ON e.student_id = s.student_id
		JOIN Course c ON e.offering_id = c.course_id

/*Trigger for Student Deletion: 
This trigger will be set up to prevent accidental deletion of student records. 
It will check if the student has any related records in other tables e.g. Financial or Assessment 
and raise an error if so, preventing the deletion from proceeding.*/
go
CREATE TRIGGER PreventStudentDeletion
ON Student
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT * FROM Financial WHERE student_id IN (SELECT deleted.student_id FROM deleted))
    BEGIN
        RAISERROR('Cannot delete student with financial records', 16, 1)
        ROLLBACK TRANSACTION;
    END
    ELSE IF EXISTS (SELECT * FROM Assessment WHERE Student_id IN (SELECT deleted.student_id FROM deleted))
    BEGIN
        RAISERROR('Cannot delete student with assessment records', 16, 1)
        ROLLBACK TRANSACTION;
    END
    ELSE
    BEGIN
        DELETE FROM Student WHERE student_id IN (SELECT deleted.student_id FROM deleted)
    END
END


/*Function for Calculating Final Exam Scores: 
This function will take input parameters for the enrollment ID and weights for the different 
assessment components e.g. mid-term score, attendance score, weekly assessment score 
and use them to calculate the final exam score for the corresponding student.*/

Go
CREATE FUNCTION CalculateFinalExamScore (@enrollment_id INT, @mid_term_weight FLOAT, 
@attendance_weight FLOAT, @weekly_weight FLOAT)
RETURNS FLOAT
AS
BEGIN
    DECLARE @mid_term_score INT, @attendance_score INT, @weekly_score INT, @final_score FLOAT;
    SELECT @mid_term_score = mid_term_score, @attendance_score = attendance_score, 
    @weekly_score = weekly_assessment_score
    FROM Enrollment WHERE enrollment_id = @enrollment_id;

    SET @final_score = (@mid_term_weight * @mid_term_score) 
    + (@attendance_weight * @attendance_score) + (@weekly_weight * @weekly_score);
    RETURN @final_score;
END


/*Index for Improving Performance: 
This index will be created on the Enrollment table to speed up queries that involve filtering 
or sorting by the grade or attendance_score columns. This will be particularly useful for generating
reports or analytics based on student performance.*/
Go
CREATE INDEX Enrollment_Grade_Attendance ON Enrollment (grade, attendance_score);


-- Procedure to return the information of a student and their scores to check the performance per course for the given variable values

GO
CREATE PROCEDURE student_course_score (@studentid INT, @sfirstname VARCHAR(50), @slastname VARCHAR(50))
		AS BEGIN
		  SELECT s.student_id, first_name, last_name, email, AssessmentID, Score, AssessmentDate, c.course_name
		FROM Assessment ass
		LEFT JOIN Student s
		ON ass.student_id = s.student_id
		LEFT JOIN Course c
		ON ass.course_id = c.course_id

							/*LEFT JOIN Final_Exam fe
							ON ass.course_id = fe.course_id*/
		 WHERE s.student_id = @studentid OR first_name =@sfirstname OR @slastname = last_name;
		END;



GO
-- the admin_metrics provides a unit amount of student admissions for the particular year value provided by the user.
CREATE PROCEDURE admin_metrics
		(@studentid INT, @course_id INT, @course_name VARCHAR(50) , @enrollment_status  VARCHAR(50), @year INT )

AS
BEGIN
	SELECT COUNT(student_id) AS [Nr of Students], co.course_id, c.course_name AS [Course Name], e.status AS [Enrollment Status], YEAR(co.start_date) AS Year
	FROM Enrollment e
	INNER JOIN Course_Offering co ON e.offering_id = co.offering_id
	INNER JOIN Course  c ON co.course_id = c.course_id
	WHERE e.status = 'Enrolled'
	GROUP BY student_id, co.course_id, c.course_name, e.status, co.start_date;
END;


/* enrollment_status stored procedure displays the infromation of the student such as student id,
	first and last name and the students course information such as the startdate, enddate, 
	course name and the enrollment status. 
	The student id, student first name and last name are taken from the input parameters
	to provide the aforementioned student information. */

GO
CREATE PROCEDURE enrollment_status
		(@studentid INT, @sfirstname VARCHAR(50), @slastname VARCHAR(50))

AS
BEGIN
SELECT s.student_id, first_name, last_name, course_name, co.start_date, co.end_date, e.enrollment_id, s.status
		FROM Student s
		Join Enrollment e ON s.student_id = e.student_id 
		JOIN Course_Offering co ON e.offering_id = co.offering_id 
		JOIN Course c ON c.course_id = co.course_id 
		WHERE s.student_id = @studentid OR first_name = @sfirstname OR @slastname = last_name;
		END;
GO

-- The create login function creates a login for staff members
CREATE LOGIN MariaDR WITH PASSWORD = 'BelgiumCampus';
CREATE LOGIN John WITH PASSWORD = 'BelgiumCampusIT';
CREATE LOGIN Wick WITH PASSWORD = 'BelgiumCampusUni';
GO

--Creating a Backup for the database
BACKUP DATABASE [Belgium Campus UniversityDB] 
TO DISK = 'C:\Users\Lucky Manamela\Desktop\ProjectDBD\DataBase\BelgiumCampusUniversityDB.bak'
WITH FORMAT, INIT, NAME = 'Full Backup of Belgium Campus UniversityDB';
