USE AdventureWorks2019
--QUESTION 1--
/*SELECT DISTINCT Employee.BusinessEntityID, Employee.NationalIDNumber, Person.FirstName, Person.LastName , Department.Name AS'Department', Employee.JobTitle
FROM HumanResources.Employee

	INNER JOIN  Person.Person
	ON Employee.BusinessEntityID = Person.BusinessEntityID

	INNER JOIN HumanResources.EmployeeDepartmentHistory
	ON HumanResources.Employee.BusinessEntityID = HumanResources.EmployeeDepartmentHistory.BusinessEntityID

	INNER JOIN HumanResources.Department
	ON HumanResources.EmployeeDepartmentHistory.DepartmentID = HumanResources.Department.DepartmentID

WHERE Employee.OrganizationLevel = 1 AND EndDate IS NULL
ORDER BY BusinessEntityID*/

--QUESTION 2--

/*
;
WITH 

total_purchases AS (
    SELECT 
      ShipMethodID, 
      SUM(TotalDue) AS purchases_total 
    FROM 
      Purchasing.PurchaseOrderHeader 
    GROUP BY 
      ShipMethodID
  ),
  total_sales AS (
    SELECT 
      ShipMethodID, 
      SUM(TotalDue) AS sales_total 
    FROM 
      Sales.SalesOrderHeader 
    GROUP BY 
      ShipMethodID
  ),shipping_methods AS (
    SELECT 
      ShipMethodID, 
      Name 
    FROM 
      Purchasing.ShipMethod 
  )
SELECT 
  sm.ShipMethodID, 
  sm.Name, 
   ROUND(ts.sales_total, 2) AS TotalSales,
  ROUND(tp.purchases_total, 2) AS TotalPurchase
FROM 
  shipping_methods sm 
  LEFT JOIN total_purchases tp 
  ON sm.ShipMethodID = tp.ShipMethodID
  
  LEFT JOIN total_sales ts 
  ON sm.ShipMethodID = ts.ShipMethodID 

ORDER BY 
  sm.ShipMethodID DESC;*/

  --QUESTION 3--

  /*SELECT  Person.Title, Person.FirstName, Person.LastName, 
       CASE 
            WHEN Person.PersonType = 'SC' THEN 'Store Contact' 
            WHEN Person.PersonType = 'IN' THEN 'Individual Customer' 
            WHEN Person.PersonType = 'SP' THEN 'Sales Person' 
            WHEN Person.PersonType = 'EM' THEN 'Employee' 
            WHEN Person.PersonType = 'VC' THEN 'Vendor Contact' 
            WHEN Person.PersonType = 'GC' THEN 'General Contact' 
            ELSE 'Unknown' 
       END AS 'Person Type'
FROM Person.Person 
FULL OUTER JOIN Sales.Store
ON Sales.Store.BusinessEntityID= Person.Person.BusinessEntityID*/

--QUESTION 4--

/*DECLARE @product_productID int ;
DECLARE @product_number NVARCHAR(50);
DECLARE @product_name NVARCHAR(50);
DECLARE @product_description nvarchar(255);
DECLARE @product_startDate date;
DECLARE @product_endDate date;


DECLARE spOffer_Cursor CURSOR FOR
		SELECT Production.Product.ProductId,Production.Product.Name, ProductNumber, Description, StartDate, EndDate
		FROM Sales.SpecialOfferProduct 
		INNER JOIN Sales.SpecialOffer 
		ON Sales.SpecialOfferProduct.SpecialOfferID = Sales.SpecialOffer.SpecialOfferID
		JOIN Production.Product
		ON Sales.SpecialOfferProduct.ProductID = Production.Product.ProductID
		WHERE Product.ProductID = 707

OPEN spOffer_cursor

FETCH NEXT FROM spOffer_cursor
INTO @product_productID, @product_number, @product_name, @product_description,@product_startDate, @product_endDate

PRINT 'Product Number: ' + @product_number;
PRINT 'Product Name: '  + @product_name;
PRINT 'Special Offer: ' 

WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT CAST(@product_startDate AS VARCHAR ) + ' '+ 'to' + ' ' + CAST(@product_endDate AS VARCHAR) + ' ' + @product_description
  
    FETCH NEXT FROM spOffer_cursor
    INTO @product_productID, @product_number, @product_name, @product_description,@product_startDate, @product_endDate
END
CLOSE spOffer_cursor;
DEALLOCATE spOffer_cursor;*/

--QUESTION 5--
/*GO
CREATE VIEW  viewStoreSales (CustomerID, StoreName, OrderYear, TotalSales )
	AS 
	SELECT Sales.Customer.CustomerID, Store.Name, YEAR(Sales.SalesOrderHeader.OrderDate) AS 'Year', ROUND(SUM(Sales.SalesOrderHeader.TotalDue),2)
	FROM Sales.Customer
	INNER JOIN Sales.Store
	ON Sales.Customer.StoreID = Sales.Store.BusinessEntityID
	INNER JOIN Sales.SalesOrderHeader
	ON Sales.Customer.CustomerID = Sales.SalesOrderHeader.CustomerID
	GROUP BY 
  Sales.Customer.CustomerID, 
    Store.Name, 
  YEAR(SalesOrderHeader.OrderDate);
	GO

SELECT *
FROM 
  viewStoreSales 
WHERE 
  TotalSales > 100000 
ORDER BY 
  CustomerID ASC, 
  OrderYear DESC;*/



